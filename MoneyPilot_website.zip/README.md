# MoneyPilot — $0-upfront starter website

This is a static website designed to be launched without paying for hosting.

## Files
- index.html — main page
- styles.css — design
- script.js — calculator and demo signup

## Monetization plan
1. Publish useful money-saving / side-income articles.
2. Apply to relevant affiliate programs and add clearly disclosed affiliate links.
3. Add display advertising after you have enough traffic and meet an ad network's requirements.
4. Sell a simple digital product (budget spreadsheet, checklist, guide) through a free-to-start storefront.
5. Build an email list and send genuinely useful weekly content.

## Free launch
Use a static hosting service that offers a free tier, such as GitHub Pages, Cloudflare Pages, or Netlify's free tier. Connect your domain later if you decide to buy one.

## Before launch
- Replace demo links with real articles.
- Connect the newsletter form to an email service.
- Add a real privacy policy and affiliate disclosure.
- Never claim guaranteed investment returns or guaranteed passive income.
- If publishing investment-related content, review applicable U.S. financial advertising/disclosure requirements.

## Important
No website can guarantee passive income. Traffic, affiliate approval, ad rates, conversion rates, and search rankings can vary substantially.

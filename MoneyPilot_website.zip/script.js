function calculateSavings(){
  const n = id => Math.max(0, Number(document.getElementById(id).value) || 0);
  const monthly = n("subs")+n("food")+n("other");
  document.getElementById("annual").textContent = "$"+Math.round(monthly*12).toLocaleString();
  document.getElementById("heroSavings").textContent = "$"+Math.round(monthly).toLocaleString();
}
function subscribe(e){
  e.preventDefault();
  const email=document.getElementById("email").value;
  alert("Demo signup received for "+email+". Connect this form to a free email provider before launch.");
}
calculateSavings();
